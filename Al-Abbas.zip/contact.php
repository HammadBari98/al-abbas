<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

<title>AL ALBBAS | CONTACT</title>

<!-- Fav Icon -->
<link rel="icon" href="contact/images/favicon.ico" type="image/x-icon">

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

<!-- Stylesheets -->
<link href="contact/css/font-awesome-all.css" rel="stylesheet">
<link href="contact/css/flaticon.css" rel="stylesheet">
<link href="contact/css/owl.css" rel="stylesheet">
<link href="contact/css/bootstrap.css" rel="stylesheet">
<link href="contact/css/jquery.fancybox.min.css" rel="stylesheet">
<link href="contact/css/animate.css" rel="stylesheet">
<link href="contact/css/color.css" rel="stylesheet">
<link href="contact/css/elpath.css" rel="stylesheet">
<link href="contact/css/jquery-ui.css" rel="stylesheet">
<link href="contact/css/nice-select.css" rel="stylesheet">
<link href="contact/css/style.css" rel="stylesheet">
<link href="contact/css/responsive.css" rel="stylesheet">

</head>


<!-- page wrapper -->
<body>

    <div class="boxed_wrapper">


        <!-- preloader -->
        <div class="loader-wrap">
            <div class="preloader">
                <div class="preloader-close">x</div>
                <div id="handle-preloader" class="handle-preloader">
                    <div class="animation-preloader">
                        <div class="spinner"></div>
                        <div class="txt-loading">
                            <span data-text-preloader="a" class="letters-loading">
                                a
                            </span>
                            <span data-text-preloader="l" class="letters-loading">
                                l
                            </span>
                            <span data-text-preloader="-" class="letters-loading">
                                -
                            </span>
                            <span data-text-preloader="a" class="letters-loading">
                                a
                            </span>
                            <span data-text-preloader="b" class="letters-loading">
                                b
                            </span>
                            <span data-text-preloader="b" class="letters-loading">
                                b
                            </span>
                            <span data-text-preloader="a" class="letters-loading">
                                a
                            </span>
                            <span data-text-preloader="s" class="letters-loading">
                                s
                            </span>
                        </div>
                    </div>  
                </div>
            </div>
        </div>
        <!-- preloader end -->



        <?php include 'header.php'?> 



        <!-- Page Title -->
        <section class="page-title centred">
            <div class="bg-layer parallax-bg" data-parallax='{"y": 100}' style="background-image: url(contact/images/background/page-title.jpg);"></div>
            <div class="auto-container">
                <div class="content-box">
                    <h2>Contact Us</h2>
                    <ul class="bread-crumb clearfix">
                        <li><a href="index.php">Home</a></li>
                        <li>Contact Us</li>
                    </ul>
                </div>
            </div>
        </section>
        <!-- End Page Title -->


        <!-- google-map-section -->
        <section class="google-map-section">
            <div class="map-inner p_relative d_block">
                <div 
                    class="google-map" 
                    id="contact-google-map" 
                    data-map-lat="40.712776" 
                    data-map-lng="-74.005974" 
                    data-icon-path="contact/images/icons/map-marker.png"  
                    data-map-title="Brooklyn, New York, United Kingdom" 
                    data-map-zoom="12" 
                    data-markers='{
                        "marker-1": [40.712776, -74.005974, "<h4>Branch Office</h4><p>77/99 New York</p>","contact/images/icons/map-marker.png"]
                    }'>

                </div>
            </div>
        </section>
        <!-- google-map-section end -->


        <!-- contact-style-three -->
        <section class="contact-style-three">
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="col-lg-4 col-md-12 col-sm-12 info-column">
                        <div class="contact-info mr_70">
                            <h3>Get In Touch</h3>
                            <p>Give us a call or drop by anytime, we answer all enquiries within 24 hours.</p>
                            <ul class="info-list clearfix">
                                <li>Modesto, 629 12th St, CA 95354 United States</li>
                                <li><a href="mailto:infomain@gmail.com">infomain@gmail.com</a></li>
                                <li><a href="tel:123045615523">+1 (230)-456-155-23</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-8 col-md-12 col-sm-12 form-column">
                        <div class="form-inner">
                            <form method="post" action="sendemail.php" id="contact-form"> 
                                <div class="row clearfix">
                                    <div class="col-lg-6 col-md-6 col-sm-12 form-group">
                                        <input type="text" name="username" placeholder="Your Name" required="">
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-12 form-group">
                                        <input type="email" name="email" placeholder="Your email" required="">
                                    </div>
                                    <div class="col-lg-12 col-md-12 col-sm-12 form-group">
                                        <input type="text" name="phone" required="" placeholder="Phone">
                                    </div>
                                    <div class="col-lg-12 col-md-12 col-sm-12 form-group">
                                        <textarea name="message" placeholder="Message"></textarea>
                                    </div>
                                    <div class="col-lg-12 col-md-12 col-sm-12 form-group">
                                        <div class="check-box">
                                            <input class="check" type="checkbox" id="checkbox">
                                            <label for="checkbox">I agree that my submitted data is being collected and stored. *</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 col-md-12 col-sm-12 form-group message-btn mr-0">
                                        <button class="theme-btn btn-one" type="submit" name="submit-form">Send Message <i class="far fa-angle-right"></i></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- contact-style-three end -->


      


        <?php include 'footer.php' ?>



        <!--Scroll to top-->
        <div class="scroll-to-top">
            <div>
                <div class="scroll-top-inner">
                    <div class="scroll-bar">
                        <div class="bar-inner"></div>
                    </div>
                    <div class="scroll-bar-text">Go To Top</div>
                </div>
            </div>
        </div>
        <!-- Scroll to top end -->
        
    </div>


    <!-- jequery plugins -->
    <script src="contact/js/jquery.js"></script>
    <script src="contact/js/popper.min.js"></script>
    <script src="contact/js/bootstrap.min.js"></script>
    <script src="contact/js/plugins.js"></script>
    <script src="contact/js/owl.js"></script>
    <script src="contact/js/wow.js"></script>
    <script src="contact/js/validation.js"></script>
    <script src="contact/js/jquery.fancybox.js"></script>
    <script src="contact/js/appear.js"></script>
    <script src="contact/js/scrollbar.js"></script>
    <script src="contact/js/isotope.js"></script>
    <script src="contact/js/jquery.nice-select.min.js"></script>
    <script src="contact/js/jquery-ui.js"></script>
    <script src="contact/js/parallax-scroll.js"></script>
    <script src="contact/js/product-filter.js"></script>
    <script src="contact/js/jquery.bootstrap-touchspin.js"></script>

    <!-- map script -->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA-CE0deH3Jhj6GN4YvdCFZS7DpbXexzGU"></script>
    <script src="contact/js/gmaps.js"></script>
    <script src="contact/js/map-helper.js"></script>

    <!-- main-js -->
    <script src="contact/js/script.js"></script>

</body><!-- End of .page_wrapper -->
</html>
