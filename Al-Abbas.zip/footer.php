  <!-- subscribe-section -->
  <section class="subscribe-section p_relative">
    <div class="auto-container">
        <div class="inner-container">
            <div class="row align-items-center clearfix">
                <div class="col-lg-6 col-md-12 col-sm-12 text-column">
                    <div class="text p_relative d_block">
                        <h2>Subscribe to Our Newsletter</h2>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12 col-sm-12 form-column">
                    <div class="form-inner p_relative d_block">
                        <form action="index.php" method="post">
                            <div class="form-group">
                                <input type="email" name="email" placeholder="Your email address" required="">
                                <button type="submit">Subscribe Now<i class="icon-7"></i></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- subscribe-section end -->
<!-- main-footer -->
<footer class="main-footer p_relative bg-color-2">
    <div class="icon-layer"><img src="contact/images/icons/icon-5.png" alt=""></div>
    <div class="footer-top p_relative d_block">
        <div class="auto-container">
            <div class="row clearfix">
                <div class="col-lg-4 col-md-6 col-sm-12 footer-column">
                    <div class="footer-widget logo-widget">
                        <figure class="footer-logo"><a href="index.php"><img src="logo.png" style="width:100px" alt=""></a></figure>
                        <div class="text">
                            <p>We are dealing all types electrical works, Waring, Security system, electrical panel, lighting</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-12 footer-column">
                    <div class="footer-widget links-widget ml_100">
                        <div class="widget-title">
                            <h3>Links</h3>
                        </div>
                        <div class="widget-content">
                            <ul class="links-list clearfix">
                                <li><a href="index.php">Home</a></li>
                                <li><a href="about.php">About</a></li>
                                <li><a href="service.php">Services</a></li>
                                <li><a href="contact.php">Contact</a></li>
                                <li><a href="shop.php">Shop</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6 col-sm-12 footer-column">
                    <div class="footer-widget links-widget">
                        <div class="widget-title">
                            <h3>Services</h3>
                        </div>
                        <div class="widget-content">
                            <ul class="links-list clearfix">
                                <li><a href="#">Service 1</a></li>
                                <li><a href="#">Service 2</a></li>
                                <li><a href="#">Service 3</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-12 footer-column">
                    <div class="footer-widget contact-widget">
                        <div class="widget-title">
                            <h3>Contacts</h3>
                        </div>
                        <div class="widget-content">
                            <ul class="info-list clearfix">
                                <li>Office S/1 Ammer Yasir society phase II malir karachi </li>
                                <li><a href="tel:23055873407">0340-4849424</a></li>
                                <li><a href="mailto:rameez@alabbaselectric.com">rameez@alabbaselectric.com</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-bottom p_relative">
        <div class="auto-container">
            <div class="bottom-inner p_relative">
                <div class="copyright"><p><a href="index.php">Al Abbas</a> &copy; 2022 All Right Reserved</p></div>
                <ul class="footer-nav">
                    <li><a href="index.php">Terms of Service</a></li>
                    <li><a href="index.php">Privacy Policy</a></li>
                </ul>
            </div>
        </div>
    </div>
</footer>
<!-- main-footer end -->