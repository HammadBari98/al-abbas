<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 <!--Search Popup-->
 <div id="search-popup" class="search-popup">
    <div class="popup-inner">
        <div class="upper-box clearfix">
            <figure class="logo-box pull-left"><a href="index.php"><img src="logo.png" alt="" style="width:100px"></a></figure>
            <!-- <div class="close-search fa fa-close pull-right"><span class="far fa-times"></span></div> -->
            <div class="close-search fa fa-close pull-right"><span class=""></span></div>
        </div>
        <div class="overlay-layer"></div>
        <div class="auto-container">
            <div class="search-form">
                <form method="post" action="index.php">
                    <div class="form-group">
                        <fieldset>
                            <input type="search" class="form-control" name="search-input" value="" placeholder="Type your keyword and hit" required >
                            <button type="submit"><i class="fa fa-search"></i></button>
                        </fieldset>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<header class="main-header">
    <!-- header-top -->
    <div class="header-top">
        <div class="top-inner">
            <div class="left-column">
                <ul class="info clearfix">
                    <li><i class="fa fa-phone" aria-hidden="true"></i> 0340-4849424 </li>
                    <!-- <li><i class="icon-1"></i></li> -->
                    <li><i class="fa fa-map-marker"></i>Office S/1 Ammer Yasir society phase II malir karachi </li>
                    <li><i class="fa fa-envelope"></i><a href="mailto:rameez@alabbaselectric.com">rameez@alabbaselectric.com</a></li>
                </ul>
            </div>
            <div class="right-column">
                <ul class="social-links clearfix">
                    <li><p>Follow Us:</p></li>
                    <!-- <li><a href="index.php"><i class="fab fa-facebook-f"></i></a></li> -->
                    <li><a href="index.php"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="index.php"><i class="fa fa-twitter"></i></a></li>
                    <!-- <li><a href="index.php"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="index.php"><i class="fab fa-pinterest-p"></i></a></li> -->
                </ul>
            </div>
        </div>
    </div>
    <!-- header-lower -->
    <div class="header-lower">
        <div class="outer-box">
            <div class="menu-area clearfix">
                <div class="logo-box">
                    <figure class="logo"><a href="index.php"><img src="logo.png" alt="" style="width: 59px;"></a></figure>
                </div>
                <!--Mobile Navigation Toggler-->
                <div class="mobile-nav-toggler">
                    <i class="icon-bar"></i>
                    <i class="icon-bar"></i>
                    <i class="icon-bar"></i>
                </div>
                <nav class="main-menu navbar-expand-md navbar-light">
                    <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">
                        <ul class="navigation clearfix">
                            <!-- <li class="current dropdown"><a href="index.php">Home</a>
                                <ul>
                                    <li><a href="index.php">Home Page 01</a></li>
                                    <li><a href="index-2.php">Home Page 02</a></li>
                                    <li><a href="index-3.php">Home Page 03</a></li>
                                    <li><a href="index-4.php">Home Page 04</a></li>
                                    <li><a href="index-5.php">Home Page 05</a></li>
                                    <li><a href="index-6.php">Home Page 06</a></li>
                                    <li><a href="index-onepage.php">OnePage Home</a></li>
                                    <li><a href="index-rtl.php">RTL Home</a></li>
                                    <li class="dropdown"><a href="index.php">Header Style</a>
                                        <ul>
                                            <li><a href="index.php">Header Style 01</a></li>
                                            <li><a href="index-2.php">Header Style 02</a></li>
                                            <li><a href="index-3.php">Header Style 03</a></li>
                                            <li><a href="index-4.php">Header Style 04</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </li> -->
                            <li><a href="index.php">Home</a></li>

                            <li><a href="about.php">About</a></li>
                            <li><a href="service.php">Services</a></li>
                            <!-- <li class="dropdown"><a href="service.php">Services</a>
                                <ul>
                                    <li><a href="#">Services 1</a></li>
                                    <li><a href="#">Services 2</a></li>
                                    <li><a href="#">Services 3</a></li>
                                    <li><a href="air-conditioning.php">Air Conditioning</a></li>
                                    <li><a href="heating-service.php">Heating Service</a></li>
                                    <li><a href="power-outlets.php">Power Outlets</a></li>
                                    <li><a href="indoor-lighting.php">Indoor Lighting</a></li>
                                    <li><a href="security-system.php">Security System</a></li>
                                    <li><a href="electrical-panels.php">Electrical Panels</a></li>
                                </ul>
                            </li> -->
                            <!-- <li class="dropdown"><a href="index.php">Pages</a>
                                <ul>
                                    <li class="dropdown"><a href="index.php">Team</a>
                                        <ul>
                                            <li><a href="team.php">Our Team 1</a></li>
                                            <li><a href="team-2.php">Our Team 2</a></li>
                                            <li><a href="team-details.php">Team Details</a></li>
                                        </ul>
                                    </li>
                                    <li class="dropdown"><a href="index.php">Project</a>
                                        <ul>
                                            <li><a href="project.php">Projects 1</a></li>
                                            <li><a href="project-2.php">Projects 2</a></li>
                                            <li><a href="project-details.php">Project Details 1</a></li>
                                            <li><a href="project-details-2.php">Project Details 2</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="testimonial.php">Testimonial</a></li>
                                    <li><a href="pricing.php">Pricing Table</a></li>
                                    <li><a href="faq.php">Faq’s</a></li>
                                    <li><a href="appointment.php">Appointment</a></li>
                                    <li><a href="error.php">404</a></li>
                                </ul>
                            </li>   -->
                            <!-- <li class="dropdown"><a href="index.php">Shop</a>
                                <ul>
                                    <li><a href="shop.php">Our Shop</a></li>
                                    <li><a href="shop-details.php">Shop Details</a></li>
                                    <li><a href="cart.php">Cart Page</a></li>
                                    <li><a href="checkout.php">Checkout</a></li>
                                </ul>
                            </li>  -->
                            <!-- <li class="dropdown"><a href="index.php">Blog</a>
                                <ul>
                                    <li><a href="blog.php">Blog Grid</a></li>
                                    <li><a href="blog-2.php">Blog Standard</a></li>
                                    <li><a href="blog-details.php">Blog Details</a></li>
                                </ul>
                            </li>   -->
                            <li><a href="shop.php">Shop</a></li> 
                            <li><a href="contact.php">Contact</a></li> 
                        </ul>
                    </div>
                </nav>
            </div>
            <div class="nav-right">
                <div class="support-box">
                    <h6><i class="icon-4"></i>Call: <a href="tel:0340-4849424">0340-4849424</a></h6>
                </div>
                <div class="search-box-outer search-toggler">
                    <i class="fa fa-search"></i>

                </div>
                <div class="btn-box">
                    <a href="index.php" class="theme-btn btn-one">Appointment</a>
                </div>
            </div>
        </div>
    </div>

    <!--sticky Header-->
    <div class="sticky-header">
        <div class="outer-box">
            <div class="menu-area clearfix">
                <div class="logo-box">
                    <figure class="logo"><a href="index.php"><img src="logo.png" style="height:60px" alt=""></a></figure>
                </div>
                <nav class="main-menu clearfix">
                    <!--Keep This Empty / Menu will come through Javascript-->
                </nav>
            </div>
            <div class="nav-right">
                <div class="support-box">
                    <h6><i class="icon-4"></i>Call: <a href="tel:123045615523">+1 (230)-456-155-23</a></h6>
                </div>
                <div class="search-box-outer search-toggler">
                    <i class="fa fa-search"></i>
                </div>
                <div class="btn-box">
                    <a href="index.php" class="theme-btn btn-one">Appointment</a>
                </div>
            </div>
        </div>
    </div>
</header>
<!-- main-header end -->

        
        
<!-- Mobile Menu  -->
<div class="mobile-menu">
    <div class="menu-backdrop"></div>
    <div class="close-btn"><i class="fas fa-times"></i></div>
    
    <nav class="menu-box">
        <div class="nav-logo"><a href="index.php"><img src="logo.png" alt="" title=""></a></div>
        <div class="menu-outer"><!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header--></div>
        <div class="contact-info">
            <h4>Contact Info</h4>
            <ul>
                <li>Chicago 12, Melborne City, USA</li>
                <li><a href="tel:+8801682648101">+88 01682648101</a></li>
                <li><a href="mailto:info@example.com">info@example.com</a></li>
            </ul>
        </div>
        <div class="social-links">
            <ul class="clearfix">
                <li><a href="index.php"><span class="fab fa-twitter"></span></a></li>
                <li><a href="index.php"><span class="fab fa-facebook-square"></span></a></li>
                <li><a href="index.php"><span class="fab fa-pinterest-p"></span></a></li>
                <li><a href="index.php"><span class="fab fa-instagram"></span></a></li>
                <li><a href="index.php"><span class="fab fa-youtube"></span></a></li>
            </ul>
        </div>
    </nav>
</div><!-- End Mobile Menu -->