<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">


<title>AL ALBBAS | SERVICE</title>

<!-- Fav Icon -->
<link rel="icon" href="service/images/favicon.ico" type="image/x-icon">

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

<!-- Stylesheets -->
<link href="service/css/font-awesome-all.css" rel="stylesheet">
<link href="service/css/flaticon.css" rel="stylesheet">
<link href="service/css/owl.css" rel="stylesheet">
<link href="service/css/bootstrap.css" rel="stylesheet">
<link href="service/css/jquery.fancybox.min.css" rel="stylesheet">
<link href="service/css/animate.css" rel="stylesheet">
<link href="service/css/color.css" rel="stylesheet">
<link href="service/css/elpath.css" rel="stylesheet">
<link href="service/css/jquery-ui.css" rel="stylesheet">
<link href="service/css/style.css" rel="stylesheet">
<link href="service/css/responsive.css" rel="stylesheet">

</head>


<!-- page wrapper -->
<body>

    <div class="boxed_wrapper">


        <!-- preloader -->
        <div class="loader-wrap">
            <div class="preloader">
                <div class="preloader-close">x</div>
                <div id="handle-preloader" class="handle-preloader">
                    <div class="animation-preloader">
                        <div class="spinner"></div>
                        <div class="txt-loading">
                            <span data-text-preloader="a" class="letters-loading">
                                a
                            </span>
                            <span data-text-preloader="l" class="letters-loading">
                                l
                            </span>
                            <span data-text-preloader="-" class="letters-loading">
                                -
                            </span>
                            <span data-text-preloader="a" class="letters-loading">
                                a
                            </span>
                            <span data-text-preloader="b" class="letters-loading">
                                b
                            </span>
                            <span data-text-preloader="b" class="letters-loading">
                                b
                            </span>
                            <span data-text-preloader="a" class="letters-loading">
                                a
                            </span>
                            <span data-text-preloader="s" class="letters-loading">
                                s
                            </span>
                        </div>
                    </div>  
                </div>
            </div>
        </div>
        <!-- preloader end -->


     

        <!-- main header -->
       
        <?php include 'header.php'?> 
       


        <!-- Page Title -->
        <section class="page-title centred">
            <div class="bg-layer parallax-bg" data-parallax='{"y": 100}' style="background-image: url(service/images/background/page-title.jpg);"></div>
            <div class="auto-container">
                <div class="content-box">
                    <h2>Services</h2>
                    <ul class="bread-crumb clearfix">
                        <li><a href="index.php">Home</a></li>
                        <li>Services </li>
                    </ul>
                </div>
            </div>
        </section>
        <!-- End Page Title -->


        <!-- service-style-two -->
        <section class="service-style-two service-page-1 sec-pad">
            <div class="auto-container">
                <div class="sec-title p_relative centred mb_50">
                    <h5 class="d_block fs_17 lh_25 fw_medium mb_9">Our Services</h5>
                    <h2 class="d_block fs_40 lh_50 fw_bold">We are a Full Service Electrical <br />Contractor</h2>
                </div>
                <div class="row clearfix">
                    <div class="col-lg-4 col-md-6 col-sm-12 service-block">
                        <div class="service-block-one">
                            <div class="inner-box">
                                <div class="image-box p_relative d_block">
                                    <div class="shape-1 p_absolute l_0 b_0"></div>
                                    <div class="shape-2 p_absolute l_0 b_0"></div>
                                    <figure class="image p_relative d_block"><a href="#"><img src="service/images/service/service-3.jpg" alt=""></a></figure>
                                </div>
                                <div class="lower-content p_relative d_block">
                                    <div class="icon-box p_absolute r_30 w_90 h_90 lh_90 fs_40 b_radius_50 centred"><i class="icon-15"></i></div>
                                    <h3><a href="#">Air Conditioning</a></h3>
                                    <p>Lorem ipsum dolor amet consectur adicing elit sed.</p>
                                    <div class="link"><a href="#">Read more<i class="icon-7"></i></a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 service-block">
                        <div class="service-block-one">
                            <div class="inner-box">
                                <div class="image-box p_relative d_block">
                                    <div class="shape-1 p_absolute l_0 b_0"></div>
                                    <div class="shape-2 p_absolute l_0 b_0"></div>
                                    <figure class="image p_relative d_block"><a href="#"><img src="service/images/service/service-4.jpg" alt=""></a></figure>
                                </div>
                                <div class="lower-content p_relative d_block">
                                    <div class="icon-box p_absolute r_30 w_90 h_90 lh_90 fs_40 b_radius_50 centred"><i class="icon-16"></i></div>
                                    <h3><a href="#">Heating Service</a></h3>
                                    <p>Lorem ipsum dolor amet consectur adicing elit sed.</p>
                                    <div class="link"><a href="#">Read more<i class="icon-7"></i></a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 service-block">
                        <div class="service-block-one">
                            <div class="inner-box">
                                <div class="image-box p_relative d_block">
                                    <div class="shape-1 p_absolute l_0 b_0"></div>
                                    <div class="shape-2 p_absolute l_0 b_0"></div>
                                    <figure class="image p_relative d_block"><a href="#"><img src="service/images/service/service-5.jpg" alt=""></a></figure>
                                </div>
                                <div class="lower-content p_relative d_block">
                                    <div class="icon-box p_absolute r_30 w_90 h_90 lh_90 fs_40 b_radius_50 centred"><i class="icon-17"></i></div>
                                    <h3><a href="#">Eectrical Service</a></h3>
                                    <p>Lorem ipsum dolor amet consectur adicing elit sed.</p>
                                    <div class="link"><a href="#">Read more<i class="icon-7"></i></a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 service-block">
                        <div class="service-block-one">
                            <div class="inner-box">
                                <div class="image-box p_relative d_block">
                                    <div class="shape-1 p_absolute l_0 b_0"></div>
                                    <div class="shape-2 p_absolute l_0 b_0"></div>
                                    <figure class="image p_relative d_block"><a href=""><img src="service/images/service/service-12.jpg" alt=""></a></figure>
                                </div>
                                <div class="lower-content p_relative d_block">
                                    <div class="icon-box p_absolute r_30 w_90 h_90 lh_90 fs_40 b_radius_50 centred"><i class="icon-18"></i></div>
                                    <h3><a href="">Security System</a></h3>
                                    <p>Lorem ipsum dolor amet consectur adicing elit sed.</p>
                                    <div class="link"><a href="">Read more<i class="icon-7"></i></a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 service-block">
                        <div class="service-block-one">
                            <div class="inner-box">
                                <div class="image-box p_relative d_block">
                                    <div class="shape-1 p_absolute l_0 b_0"></div>
                                    <div class="shape-2 p_absolute l_0 b_0"></div>
                                    <figure class="image p_relative d_block"><a href="#"><img src="service/images/service/service-13.jpg" alt=""></a></figure>
                                </div>
                                <div class="lower-content p_relative d_block">
                                    <div class="icon-box p_absolute r_30 w_90 h_90 lh_90 fs_40 b_radius_50 centred"><i class="icon-19"></i></div>
                                    <h3><a href="#">Power Outlets</a></h3>
                                    <p>Lorem ipsum dolor amet consectur adicing elit sed.</p>
                                    <div class="link"><a href="#">Read more<i class="icon-7"></i></a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 service-block">
                        <div class="service-block-one">
                            <div class="inner-box">
                                <div class="image-box p_relative d_block">
                                    <div class="shape-1 p_absolute l_0 b_0"></div>
                                    <div class="shape-2 p_absolute l_0 b_0"></div>
                                    <figure class="image p_relative d_block"><a href="#"><img src="service/images/service/service-14.jpg" alt=""></a></figure>
                                </div>
                                <div class="lower-content p_relative d_block">
                                    <div class="icon-box p_absolute r_30 w_90 h_90 lh_90 fs_40 b_radius_50 centred"><i class="icon-20"></i></div>
                                    <h3><a href="#">Eectrical Service</a></h3>
                                    <p>Lorem ipsum dolor amet consectur adicing elit sed.</p>
                                    <div class="link"><a href="#">Read more<i class="icon-7"></i></a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- service-style-two end -->


        <?php include 'footer.php' ?>




        <!--Scroll to top-->
        <div class="scroll-to-top">
            <div>
                <div class="scroll-top-inner">
                    <div class="scroll-bar">
                        <div class="bar-inner"></div>
                    </div>
                    <div class="scroll-bar-text">Go To Top</div>
                </div>
            </div>
        </div>
        <!-- Scroll to top end -->
        
    </div>


    <!-- jequery plugins -->
    <script src="service/js/jquery.js"></script>
    <script src="service/js/popper.min.js"></script>
    <script src="service/js/bootstrap.min.js"></script>
    <script src="service/js/plugins.js"></script>
    <script src="service/js/owl.js"></script>
    <script src="service/js/wow.js"></script>
    <script src="service/js/validation.js"></script>
    <script src="service/js/jquery.fancybox.js"></script>
    <script src="service/js/appear.js"></script>
    <script src="service/js/scrollbar.js"></script>
    <script src="service/js/isotope.js"></script>
    <script src="service/js/jquery.nice-select.min.js"></script>
    <script src="service/js/jquery-ui.js"></script>
    <script src="service/js/parallax-scroll.js"></script>

    <!-- main-js -->
    <script src="service/js/script.js"></script>

</body><!-- End of .page_wrapper -->
</html>
